
from flask import Flask, render_template, request, send_from_directory, session
from werkzeug.utils import secure_filename
from datetime import timedelta
import os

from extract_utils import extract_cve_ids
from chroma_utils import (
    fetch_and_store_cves,
    fetch_cve_count,
    query_cves,
    semantic_lookup_from_id
,
    direct_lookup_from_id)

app = Flask(__name__)
app.secret_key = 'cve_secret'
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=30)
app.config['ALLOWED_EXTENSIONS'] = {'txt'}

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

@app.route('/', methods=['GET'])
def index():
    cve_count = fetch_cve_count()
    return render_template('index.html', cve_count=cve_count)

@app.route('/search', methods=['POST'])
def search():
    query = request.form.get('query')
    results = query_cves(query, top_k=5)
    cve_count = fetch_cve_count()
    return render_template('index.html', cve_count=cve_count, search_results=results)

@app.route('/extract', methods=['POST'])
def extract():
    if 'file' not in request.files:
        return render_template('index.html', error="No file provided")

    file = request.files['file']
    if file and allowed_file(file.filename):
        content = file.read().decode("utf-8", errors="ignore")
        cve_ids = extract_cve_ids(content)
        print("Extracted CVE IDs:", cve_ids)

        session['cve_ids'] = cve_ids
        session['cve_results'] = {cid: direct_lookup_from_id(cid) for cid in cve_ids}

        message = f"{len(cve_ids)} CVE ID(s) extracted from the uploaded file." if cve_ids else "No valid CVE IDs found in the uploaded file."
        return render_template('results.html', cve_ids=cve_ids, message=message)

    return render_template('index.html', error="Invalid file")

@app.route('/download')
def download():
    return send_from_directory('static', 'cve_data.txt', as_attachment=True)

fetch_and_store_cves()

if __name__ == '__main__':
    app.run(debug=True)
