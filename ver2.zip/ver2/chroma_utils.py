
import os
import gzip
import json
import requests
import chromadb
from sentence_transformers import SentenceTransformer

chroma_client = chromadb.PersistentClient(path="cve_chroma")
collection = chroma_client.get_or_create_collection(name="cves")
model = SentenceTransformer("all-MiniLM-L6-v2")

def fetch_and_store_cves():
    results = collection.get(include=["documents"])
    if results["documents"]:
        print("✔️ CVEs already loaded into ChromaDB.")
        return

    url = "https://nvd.nist.gov/feeds/json/cve/1.1/nvdcve-1.1-2024.json.gz"
    r = requests.get(url)
    with open("2024.json.gz", "wb") as f:
        f.write(r.content)

    with gzip.open("2024.json.gz", 'rt', encoding='utf-8') as f:
        data = json.load(f)

    docs, metas, ids = [], [], []
    for item in data["CVE_Items"]:
        cve_id = item["cve"]["CVE_data_meta"]["ID"]
        desc = item["cve"]["description"]["description_data"][0]["value"]
        link = f"https://nvd.nist.gov/vuln/detail/{cve_id}"
        docs.append(f"{cve_id} - {desc}")
        metas.append({"url": link})
        ids.append(cve_id)

        if len(docs) >= 100:
            collection.add(documents=docs, metadatas=metas, ids=ids, embeddings=model.encode(docs).tolist())
            docs, metas, ids = [], [], []

    if docs:
        collection.add(documents=docs, metadatas=metas, ids=ids, embeddings=model.encode(docs).tolist())

    os.makedirs("static", exist_ok=True)
    with open("static/cve_data.txt", "w", encoding="utf-8") as txt_file:
        for item in data["CVE_Items"]:
            cve_id = item["cve"]["CVE_data_meta"]["ID"]
            desc = item["cve"]["description"]["description_data"][0]["value"]
            link = f"https://nvd.nist.gov/vuln/detail/{cve_id}"
            txt_file.write(f"{cve_id}: {desc}\n{link}\n\n")



def semantic_lookup_from_id(cve_id):
    embedding = model.encode([cve_id]).tolist()
    results = collection.query(query_embeddings=embedding, n_results=5)
    return list(zip(results["documents"][0], results["metadatas"][0]))

def query_cves(query, top_k=5):
    embedding = model.encode([query]).tolist()
    results = collection.query(query_embeddings=embedding, n_results=top_k)
    return list(zip(results['documents'][0], results['metadatas'][0]))

def fetch_cve_count():
    try:
        results = collection.get(include=["documents"])
        return len(results["documents"])
    except:
        return 0


def direct_lookup_from_id(cve_id):
    try:
        result = collection.get(ids=[cve_id], include=["documents", "metadatas"])
        return list(zip(result["documents"], result["metadatas"]))
    except Exception as e:
        print(f"Error fetching CVE {cve_id}: {e}")
        return []
